import subprocess
import sys
from pathlib import Path

ROOT = Path(r"C:\Users\HP\Seminarski")

scripts = [
    "collect_idm.py",
    "train_bc.py",
    "train_straight.py",
    "train_curve.py"
]

for script in scripts:
    print(f"\n========== Pokrecem {script} ==========\n", flush=True)

    result = subprocess.run(
        [sys.executable, "-u", script],
        cwd=ROOT
    )

    if result.returncode != 0:
        print(f"\n{script} je pao. Prekidam pipeline.", flush=True)
        sys.exit(result.returncode)

print("\nSve je zavrseno.", flush=True)