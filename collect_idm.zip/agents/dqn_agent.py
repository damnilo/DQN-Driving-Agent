import torch
import numpy as np
import random
from agents.q_network import QNetwork

class DQNAgent:
    
    def __init__(self, input_size, num_steering_actions, num_throttle_actions, epsilon_scheduler):
        
        self.online_net = QNetwork(
            input_size, 
            num_steering_actions,
            num_throttle_actions
        )

        self.target_net = QNetwork(
            input_size,
            num_steering_actions,
            num_throttle_actions
        )
        
        self.num_steering_actions = num_steering_actions
        self.num_throttle_actions = num_throttle_actions

        self.epsilon_scheduler = epsilon_scheduler

        self.target_net.load_state_dict(self.online_net.state_dict())
        self.target_net.eval()

    def select_action(self, state, step, training):

        epsilon = self.epsilon_scheduler.get_epsilon(step)

        if random.random() <= epsilon and training:
            steering_action = random.randint(0, self.num_steering_actions - 1)
            throttle_action = random.randint(0, self.num_throttle_actions - 1)  

            return [steering_action, throttle_action]
                
        device = next(self.online_net.parameters()).device
        
        state_t = torch.as_tensor(
            state, dtype=torch.float32, device=device
        ).unsqueeze(0)

        with torch.no_grad():
            steering_q, throttle_q = self.online_net(state_t)

        steering_action = torch.argmax(steering_q, dim=1).item()
        throttle_action = torch.argmax(throttle_q, dim=1).item()
        return [steering_action, throttle_action]
    
    def update_target_network(self):

        self.target_net.load_state_dict(
            self.online_net.state_dict()
        )

        self.target_net.eval()