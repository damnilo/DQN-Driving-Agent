import torch.nn as nn

class QNetwork(nn.Module):
    def __init__(self, input_size, num_steering_actions, num_throttle_actions):
        super().__init__()

        self.shared = nn.Sequential(
            nn.Linear(input_size, 512), nn.ReLU(),
            nn.Linear(512, 256), nn.ReLU(),
            nn.Linear(256, 256), nn.ReLU()
        )
        
        self.steering_advantage_stream = nn.Sequential(
            nn.Linear(256, 128), nn.ReLU(),
            nn.Linear(128, num_steering_actions)
        )

        self.steering_value_stream = nn.Sequential(
            nn.Linear(256, 128), nn.ReLU(),
            nn.Linear(128, 1)
        )

        self.throttle_advantage_stream = nn.Sequential(
            nn.Linear(256, 128), nn.ReLU(),
            nn.Linear(128, num_throttle_actions)
        )

        self.throttle_value_stream = nn.Sequential(
            nn.Linear(256, 128), nn.ReLU(),
            nn.Linear(128, 1)
        )

    def forward(self, x):
        shared = self.shared(x)

        steering_value = self.steering_value_stream(shared)
        steering_advantage = self.steering_advantage_stream(shared)

        steering_q = steering_value + (steering_advantage - steering_advantage.mean(dim=1, keepdim=True))

        throttle_value = self.throttle_value_stream(shared)
        throttle_advantage = self.throttle_advantage_stream(shared)

        throttle_q = throttle_value + (throttle_advantage - throttle_advantage.mean(dim=1, keepdim=True))

        return steering_q, throttle_q