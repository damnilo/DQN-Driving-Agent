import json
import random
import numpy as np
from collections import deque
from utils.action_discretizer import discretize_steering, discretize_throttle
from typing import Tuple, List
from enviornments.action_mapper import ActionMapper
from configs.env_config import FRAME_STACK

Transition = Tuple[
    np.ndarray, np.ndarray, float, np.ndarray, bool
]

STRAIGHT_MAPS = {"SSSS"}
CURVE_MAPS = {"SCSC", "CSCS", "CCCC", "4"}

class ExpertReplayBuffer:

    def __init__(self, capacity: int, expert_dataset_path: str, num_steering_actions: int, num_throttle_actions: int, expert_ratio: float = 0.25, map_filter=None):

        self.capacity = capacity
        self.num_steering_actions = num_steering_actions
        self.num_throttle_actions = num_throttle_actions
        self.expert_ratio = expert_ratio

        self._agent_buffer: deque = deque(maxlen=capacity)

        self._expert_buffer: List[Transition] = []

        self._load_expert_data(expert_dataset_path, map_filter)

    def _load_expert_data(self, path: str, map_filter=None) -> None:

        if not path:
            return
        
        try:
            data = np.load(path, allow_pickle=True)

        except FileNotFoundError:
            print(f"[ExpertReplayBuffer] Dataset nije pronadjen")

            return

        except json.JSONDecodeError as e:
            print(f"[ExpertReplayBuffer] Ostecen JSON: {path}")
            print(f"  {e}")
            print("  Pokreni: python salvage_dataset.py")
            print("  Ili ponovo: python collect_idm.py")
            return
        
        obs_all = data["obs"]
        next_obs_all = data["next_obs"]
        actions_all = data["actions"]
        rewards_all = data["rewards"]
        dones_all = data["dones"]
        maps_all = data["maps"]

        if maps_all.dtype.kind in {'U', 'S'}:
            maps_all = np.array([m.decode("utf-8").rstrip("\x00") for m in maps_all])

        transition = []

        for i in range(len(obs_all)):
            maps_str = str(maps_all[i])
            
            if map_filter and maps_str not in map_filter:
                continue

            steering_idx = discretize_steering(float(actions_all[i][0]))
            throttle_idx = discretize_throttle(float(actions_all[i][1]))
            action_idx = np.array([steering_idx, throttle_idx], dtype=np.int64)

            transition.append((obs_all[i], action_idx, float(rewards_all[i]), next_obs_all[i], bool(dones_all[i])   ))

        self._expert_buffer = transition
        print(f"[ExpertReplayBuffer] Ucitano {len(self._expert_buffer)} ekspertskih tranzicija")

    def push(self, obs, action, reward, next_obs, done):

        self._agent_buffer.append((obs.astype(np.float32), np.array(action, dtype=np.int64), float(reward), next_obs.astype(np.float32), bool(done)))

    def sample(self, batch_size):

        n_expert = 0
        n_agent = batch_size

        has_expert = len(self._expert_buffer) > 0
        has_agent = len(self._agent_buffer) >= batch_size

        if has_expert and has_agent:
            n_expert = int(batch_size * self.expert_ratio)
            n_agent = batch_size - n_expert
        elif not has_agent and has_expert:
            n_expert = batch_size
            n_agent = 0

        samples: List[Transition] = []

        if n_expert > 0:
            samples += random.sample(self._expert_buffer, min(n_expert, len(self._expert_buffer)))

        if n_agent > 0:
            samples += random.sample(list(self._agent_buffer), min(n_agent, len(self._agent_buffer)))

        if not samples:
            raise RuntimeError("Replay Buffer je prazan. Ponovo pokreni collect_idm.py")

        obs_arr, actions_arr, rewards_arr, next_obs_arr, dones_arr = zip(*samples)

        return (np.array(obs_arr, dtype=np.float32), np.array(actions_arr, dtype=np.int64),
                np.array(rewards_arr, dtype=np.float32), np.array(next_obs_arr, dtype=np.float32),
                np.array(dones_arr, dtype=np.float32))
    
    def __len__(self):
        return len(self._agent_buffer)
    
    @property
    def agent_size(self):
        return len(self._agent_buffer)
    
    @property
    def expert_size(self):
        return len(self._expert_buffer)
    
    def is_ready(self, min_size):
        if len(self._expert_buffer) >= min_size:
            return True
        return self.agent_size >= min_size
    
    def clear_agent_buffer(self):
        self._agent_buffer.clear()