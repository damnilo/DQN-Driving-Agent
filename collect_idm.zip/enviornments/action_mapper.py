import numpy as np

class ActionMapper:
    def __init__(self):
        # Use ordered sequences (lists) so indexing is stable and deterministic
        self.steering_actions = [
            -0.50, -0.36, -0.26, -0.18, -0.12, -0.08, -0.06, -0.04, -0.02, 0.0,
            0.02, 0.04, 0.06, 0.08, 0.12, 0.18, 0.26, 0.36, 0.50
        ]

        self.throttle_actions = [
            -0.30, -0.15, 0.00, 0.20, 0.35, 0.50, 0.65
        ]

    def map(self, action):
        steering_idx, throttle_idx = action

        steering = self.steering_actions[steering_idx]
        throttle = self.throttle_actions[throttle_idx]

        return [steering, throttle]
    
    def get_steering_actions(self):
        return np.array(self.steering_actions, dtype=np.float32)
    
    def get_throttle_actions(self):
        return np.array(self.throttle_actions, dtype=np.float32)
    
    def num_actions_steering(self):
        return len(self.steering_actions)
    
    def num_actions_throttle(self):
        return len(self.throttle_actions)