from enviornments.metadrive_env import MetaDriveEnvWrapper
from configs.env_config import ENV_CONFIG
env = MetaDriveEnvWrapper(ENV_CONFIG)
obs, info = env.reset()
print("obs.shape", getattr(obs, "shape", (len(obs),)), "len:", len(obs))
action = 0
ns, r, terminated, truncated, info = env.step(action)
print("next.shape", getattr(ns, "shape", (len(ns),)), "reward:", r, "done:", terminated or truncated)
env.close()