import numpy as np
from enviornments.action_mapper import ActionMapper

action_mapper = ActionMapper()

def discretize_steering(steering):
    return int(np.argmin(np.abs(action_mapper.get_steering_actions() - steering)))

def discretize_throttle(throttle):
    return int(np.argmin(np.abs(action_mapper.get_throttle_actions() - throttle)))