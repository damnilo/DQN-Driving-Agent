"""Oporavlja prekinut expert_dataset.json (collect prekinut tokom pisanja)."""
import json
import re
import os
import shutil

from configs.env_config import EXPERT_DATASET

SALVAGED_PATH = "dataset/expert_dataset_salvaged.json"


def salvage(path: str, out_path: str) -> int:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        data = f.read()

    start = data.find("[")
    if start < 0:
        raise ValueError("Nije pronadjen JSON niz u fajlu.")

    pattern = re.compile(r'"out_of_road"\s*:\s*(?:true|false)\s*\}')
    matches = list(pattern.finditer(data))
    if not matches:
        raise ValueError("Nema kompletnih tranzicija u fajlu.")

    end = matches[-1].end()
    fixed = data[start:end] + "\n]"

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(fixed)

    with open(out_path, "r", encoding="utf-8") as f:
        records = json.load(f)

    return len(records)


def main():
    if not os.path.exists(EXPERT_DATASET):
        print(f"Fajl ne postoji: {EXPERT_DATASET}")
        return

    size_mb = os.path.getsize(EXPERT_DATASET) / (1024 * 1024)
    print(f"Ulaz: {EXPERT_DATASET} ({size_mb:.1f} MB)")

    try:
        with open(EXPERT_DATASET, "r", encoding="utf-8") as f:
            json.load(f)
        print("JSON je vec validan — nista nije potrebno.")
        return
    except json.JSONDecodeError as e:
        print(f"Ostecen JSON: {e}")

    count = salvage(EXPERT_DATASET, SALVAGED_PATH)
    print(f"Sacuvano {count} tranzicija u {SALVAGED_PATH}")

    backup = EXPERT_DATASET + ".corrupt.bak"
    if not os.path.exists(backup):
        shutil.copy2(EXPERT_DATASET, backup)
        print(f"Backup ostecenog: {backup}")

    shutil.move(SALVAGED_PATH, EXPERT_DATASET)
    print(f"Zamenjen {EXPERT_DATASET} — mozes pokrenuti train.py")


if __name__ == "__main__":
    main()
